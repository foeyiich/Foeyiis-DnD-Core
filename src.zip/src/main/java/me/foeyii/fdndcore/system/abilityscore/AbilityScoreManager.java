package me.foeyii.fdndcore.system.abilityscore;

import me.foeyii.fdndcore.DnDCore;
import me.foeyii.fdndcore.data.DnDAbilityScoreType;
import me.foeyii.fdndcore.data.DnDAttachments;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.ArrayList;
import java.util.List;

public class AbilityScoreManager {

    public record AttributeBonus(Holder<Attribute> attribute, String modifierId, double value) {
    }

    public static class AttributeModifierRate {
        private AttributeModifierRate() {
            /* This utility class should not be instantiated */
        }

        public static final float STRENGTH_ATTACK_DAMAGE = 0.3f;
        public static final float CONSTITUTION_MAX_HEALTH = 4.f;
        public static final float DEXTERITY_MOVEMENT_SPEED = 0.04f;
        public static final float DEXTERITY_SNEAKING_SPEED = 0.02f;
        public static final float WISDOM_FOLLOW_RANGE = 4.f;
    }

    public static void syncAttribute(LivingEntity entity, Holder<AbilityScoreType> type) {
        getBonuses(entity, type).forEach(bonus ->
                applyModifier(entity, bonus.attribute(), bonus.modifierId(), bonus.value)
        );
    }

    public static void syncAttributes(LivingEntity entity) {
        for (Holder<AbilityScoreType> type : DnDAbilityScoreType.ABILITY_SCORE_TYPES.getEntries()) {
            syncAttribute(entity, type);
        }
    }

    private static void applyModifier(LivingEntity entity, Holder<Attribute> attr, String name, double value) {
        AttributeInstance inst = entity.getAttribute(attr);
        if (inst != null) {
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(DnDCore.MODID, name);
            inst.removeModifier(id);
            inst.addPermanentModifier(new AttributeModifier(id, value, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    public static List<AttributeBonus> getBonuses(LivingEntity entity, Holder<AbilityScoreType> type) {
        AbilityScore stats = entity.getData(DnDAttachments.ABILITY_SCORE);
        int mod = stats.getScoreModifier(type);
        List<AttributeBonus> bonuses = new ArrayList<>();

        if (type == DnDAbilityScoreType.STRENGTH) {
            bonuses.add(new AttributeBonus(Attributes.ATTACK_DAMAGE, "str_attack_damage", mod * AttributeModifierRate.STRENGTH_ATTACK_DAMAGE));
        } else if (type == DnDAbilityScoreType.CONSTITUTION) {
            bonuses.add(new AttributeBonus(Attributes.MAX_HEALTH, "con_health", mod * AttributeModifierRate.CONSTITUTION_MAX_HEALTH));
        } else if (type == DnDAbilityScoreType.DEXTERITY) {
            bonuses.add(new AttributeBonus(Attributes.MOVEMENT_SPEED, "dex_move_speed", mod * AttributeModifierRate.DEXTERITY_MOVEMENT_SPEED));
            bonuses.add(new AttributeBonus(Attributes.SNEAKING_SPEED, "dex_sneak_speed", mod * AttributeModifierRate.DEXTERITY_SNEAKING_SPEED));
        } else if (type == DnDAbilityScoreType.WISDOM) {
            bonuses.add(new AttributeBonus(Attributes.FOLLOW_RANGE, "wis_range", mod * AttributeModifierRate.WISDOM_FOLLOW_RANGE));
        }

        return bonuses;
    }

}
