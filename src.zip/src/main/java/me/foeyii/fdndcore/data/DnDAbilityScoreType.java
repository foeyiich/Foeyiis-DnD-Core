package me.foeyii.fdndcore.data;

import me.foeyii.fdndcore.DnDCore;
import me.foeyii.fdndcore.system.abilityscore.AbilityScoreType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.RegistryBuilder;

public final class DnDAbilityScoreType {
    private DnDAbilityScoreType() {
        /* This utility class should not be instantiated */
    }

    public static final DeferredRegister<AbilityScoreType> ABILITY_SCORE_TYPES =
            DeferredRegister.create(DnDRegistries.ABILITY_SCORE, DnDCore.MODID);

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> STRENGTH =
            ABILITY_SCORE_TYPES.register("strength", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.strength",
                    "ability_score.fdnd_core.strength.abbr"
            ));

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> DEXTERITY =
            ABILITY_SCORE_TYPES.register("dexterity", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.dexterity",
                    "ability_score.fdnd_core.dexterity.abbr"
            ));

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> CONSTITUTION =
            ABILITY_SCORE_TYPES.register("constitution", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.constitution",
                    "ability_score.fdnd_core.constitution.abbr"
            ));

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> INTELLIGENCE =
            ABILITY_SCORE_TYPES.register("intelligence", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.intelligence",
                    "ability_score.fdnd_core.intelligence.abbr"
            ));

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> WISDOM =
            ABILITY_SCORE_TYPES.register("wisdom", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.wisdom",
                    "ability_score.fdnd_core.wisdom.abbr"
            ));

    public static final DeferredHolder<AbilityScoreType, AbilityScoreType> CHARISMA =
            ABILITY_SCORE_TYPES.register("charisma", () -> new AbilityScoreType(
                    "ability_score.fdnd_core.charisma",
                    "ability_score.fdnd_core.charisma.abbr"
            ));

    public static void register(IEventBus bus) {
        ABILITY_SCORE_TYPES.register(bus);
        ABILITY_SCORE_TYPES.makeRegistry(builder ->
                new RegistryBuilder<>(DnDRegistries.ABILITY_SCORE).sync(true));
    }

}
